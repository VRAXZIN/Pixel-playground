package com.vraxzin.pixelragdoll;

import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.graphics.*;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().getDecorView().setSystemUiVisibility(5894|1024|512); setContentView(new GameView()); }

    static class GameView extends View {
        Paint p = new Paint(); Random rng = new Random(); ArrayList<Body> bodies = new ArrayList<>();
        boolean started=false, menu=true, spawnMenu=false; float downX,downY; Body grabbed; int bg=Color.rgb(26,31,43); long last=System.nanoTime();
        float floorY=0, scale=1;
        GameView(){super(MainActivity.this); setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void text(Canvas c,String s,float x,float y,int size,int color){p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create("monospace",Typeface.BOLD));p.setAntiAlias(false);c.drawText(s,x,y,p);}
        void box(Canvas c,float l,float t,float r,float b,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRect(l,t,r,b,p);}
        @Override protected void onDraw(Canvas c){super.onDraw(c); float w=getWidth(),h=getHeight(); if(w==0)return; floorY=h-62; c.save(); c.scale(w/960f,h/540f); drawWorld(c); if(menu)drawMenu(c); else if(spawnMenu)drawSpawn(c); c.restore(); postInvalidateOnAnimation();}
        void drawWorld(Canvas c){box(c,0,0,960,540,bg); for(int y=0;y<500;y+=32)for(int x=0;x<960;x+=32){p.setColor(((x/32+y/32)%2==0)?0x182f4058:0x18253649);c.drawRect(x,y,x+31,y+31,p);} box(c,0,478,960,540,0xff343b48); for(int x=0;x<960;x+=24)box(c,x,478,x+2,540,0xff414b5b); box(c,0,478,960,484,0xff8d9aa9);
            long now=System.nanoTime(); float dt=Math.min(.025f,(now-last)/1e9f);last=now;
            if(!menu){for(Body b:bodies)b.step(dt); for(Body b:bodies)b.draw(c); drawHud(c);}
        }
        void drawHud(Canvas c){box(c,12,12,210,52,0xdd101722);text(c,"PIXEL RAGDOLL",23,38,17,0xffe6edf7);button(c,750,14,916,56,"+ SPAWN NPC");text(c,"Touch a ragdoll to grab and throw",18,462,13,0xffd4dce8);}
        void button(Canvas c,float x,float y,float w,float h,String s){box(c,x,y,x+w,y+h,0xff536b86);box(c,x+3,y+3,x+w-3,y+h-3,0xff26384d);text(c,s,x+12,y+h/2+6,17,0xfff3f6fa);}
        void drawMenu(Canvas c){box(c,0,0,960,540,0xe6101723);text(c,"PIXEL RAGDOLL",270,170,48,0xfff2f5fa);text(c,"PHYSICS SANDBOX",350,208,20,0xff8fb9e8);button(c,350,270,260,64,"PLAY");text(c,"2D PIXEL SANDBOX  |  ANDROID",300,390,17,0xffaebdce);}
        void drawSpawn(Canvas c){box(c,0,0,960,540,0xb9000000);box(c,290,115,670,420,0xff1a2636);text(c,"SPAWN MENU",390,160,26,0xfff2f5fa);button(c,350,195,260,58,"HUMAN RAGDOLL");button(c,350,270,260,58,"CLOSE");text(c,"NPC: articulated body with spring joints",320,380,13,0xffb8c8d9);}
        void spawn(float x,float y){bodies.add(new Body(x,y));}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){float x=e.getX()*960/getWidth(), y=e.getY()*540/getHeight(); if(e.getAction()==MotionEvent.ACTION_DOWN){downX=x;downY=y;
                if(menu){if(y>250&&y<360){menu=false;spawn(480,320);}return true;}
                if(spawnMenu){if(y>185&&y<260){spawn(480,280);spawnMenu=false;}else if(y>265&&y<345)spawnMenu=false;return true;}
                if(x>740&&y<70){spawnMenu=true;return true;} grabbed=findBody(x,y); if(grabbed!=null)grabbed.grab(x,y); return true;}
            if(e.getAction()==MotionEvent.ACTION_MOVE){if(grabbed!=null)grabbed.move(x,y);return true;}
            if(e.getAction()==MotionEvent.ACTION_UP){if(grabbed!=null){grabbed.release(x-downX,y-downY);grabbed=null;}return true;}return true;}
        Body findBody(float x,float y){for(int i=bodies.size()-1;i>=0;i--){Body b=bodies.get(i);for(Node n:b.n)if(Math.hypot(n.x-x,n.y-y)<35)return b;}return null;}
        class Node {float x,y,px,py; float r; int col; Node(float x,float y,float r,int col){this.x=this.px=x;this.y=this.py=y;this.r=r;this.col=col;}}
        class Link {int a,b;float len;Link(int a,int b,float l){this.a=a;this.b=b;len=l;}}
        class Body {ArrayList<Node> n=new ArrayList<>();ArrayList<Link> links=new ArrayList<>(); boolean held=false;float tx,ty; Body(float x,float y){int skin=0xffffbd87,shirt=0xff4e9acb,pants=0xff344b78,shoe=0xff202a38;
                n.add(new Node(x,y-65,13,skin)); // head
                n.add(new Node(x,y-37,10,shirt)); // chest
                n.add(new Node(x,y-10,9,shirt)); // waist
                n.add(new Node(x-20,y-34,7,skin));n.add(new Node(x-34,y-10,6,skin));
                n.add(new Node(x+20,y-34,7,skin));n.add(new Node(x+34,y-10,6,skin));
                n.add(new Node(x-9,y+20,8,pants));n.add(new Node(x-12,y+51,6,pants));n.add(new Node(x-15,y+72,6,shoe));
                n.add(new Node(x+9,y+20,8,pants));n.add(new Node(x+12,y+51,6,pants));n.add(new Node(x+15,y+72,6,shoe));
                connect(0,1);connect(1,2);connect(1,3);connect(3,4);connect(1,5);connect(5,6);connect(2,7);connect(7,8);connect(8,9);connect(2,10);connect(10,11);connect(11,12);
            }
            void connect(int a,int b){Node A=n.get(a),B=n.get(b);links.add(new Link(a,b,(float)Math.hypot(A.x-B.x,A.y-B.y)));}
            void step(float dt){for(Node a:n){if(held){} float vx=(a.x-a.px)*.995f,vy=(a.y-a.py)*.995f;a.px=a.x;a.py=a.y;a.x+=vx;a.y+=vy+1500*dt*dt;if(a.y>floorY-a.r){a.y=floorY-a.r;a.py=a.y+vy*.25f;}if(a.x<a.r){a.x=a.r;}if(a.x>960-a.r)a.x=960-a.r;}
                for(int k=0;k<7;k++)for(Link l:links){Node a=n.get(l.a),b=n.get(l.b);float dx=b.x-a.x,dy=b.y-a.y,d=(float)Math.sqrt(dx*dx+dy*dy);if(d<.001f)continue;float diff=(d-l.len)/d*.48f;float ox=dx*diff,oy=dy*diff;a.x+=ox;a.y+=oy;b.x-=ox;b.y-=oy;}
                if(held){Node a=n.get(0);a.x+=(tx-a.x)*.55f;a.y+=(ty-a.y)*.55f;}}
            void grab(float x,float y){held=true;tx=x;ty=y;} void move(float x,float y){tx=x;ty=y;} void release(float vx,float vy){held=false;for(Node a:n){a.px-=vx*.12f;a.py-=vy*.12f;}}
            void draw(Canvas c){for(Link l:links){Node a=n.get(l.a),b=n.get(l.b);p.setColor(0xff17212d);p.setStrokeWidth(13);p.setStrokeCap(Paint.Cap.ROUND);c.drawLine(a.x,a.y,b.x,b.y,p);p.setColor(n.get(l.a).col);p.setStrokeWidth(8);c.drawLine(a.x,a.y,b.x,b.y,p);}for(int i=0;i<n.size();i++){Node a=n.get(i);p.setColor(0xff101820);c.drawRect(a.x-a.r-2,a.y-a.r-2,a.x+a.r+2,a.y+a.r+2,p);p.setColor(a.col);c.drawRect(a.x-a.r,a.y-a.r,a.x+a.r,a.y+a.r,p);if(i==0){box(c,a.x+3,a.y-3,a.x+6,a.y,0xff252b32);box(c,a.x+3,a.y+4,a.x+8,a.y+6,0xff8b4b45);}}}
        }
    }
}
